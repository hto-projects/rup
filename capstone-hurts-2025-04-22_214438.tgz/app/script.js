function Start() {
  window.location.href = "Kwenz.html";
}
function Map() {
  window.location.href = "Map.html";
}
function BEnd() {
  window.location.href = "BEnd.html";
}
function GEnd() {
  window.location.href = "GEnd.html";
}
function Ariqi() {
  window.location.href = "Ariqi.html";
}
function Feiz() {
  window.location.href = "Feiz.html";
}
function Gydel() {
  window.location.href = "Gydel.html";
}
function Haba() {
  window.location.href = "Haba.html";
}
function Jerri() {
  window.location.href = "Jerrickus.html";
}
function Lopa() {
  window.location.href = "Lopa.html";
}
function Ne() {
  window.location.href = "Ne.html";
}
function Pusch() {
  window.location.href = "Puschus.html";
}
function SkallC() {
  window.location.href = "SkalleeCentral.html";
}
function SkallE() {
  window.location.href = "SkalleeEast.html";
}
function SkallW() {
  window.location.href = "SkalleeWest.html";
}
function Vaiya() {
  window.location.href = "Vaiya.html";
}
function Wyega() {
  window.location.href = "Wyega.html";
}
function Xyia() {
  window.location.href = "Xyia.html";
}
function Zazr() {
  window.location.href = "Zazr.html";
}